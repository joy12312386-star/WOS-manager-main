"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const user_service_1 = __importDefault(require("../services/user.service"));
const auth_2 = require("../middleware/auth");
const router = (0, express_1.Router)();
// 檢查用戶是否已存在
router.get('/check-user/:gameId', async (req, res) => {
    try {
        const { gameId } = req.params;
        if (!gameId) {
            return res.status(400).json({ error: 'gameId is required' });
        }
        const exists = await user_service_1.default.userExists(gameId);
        res.json({ exists });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 登入
router.post('/login', async (req, res) => {
    try {
        const { gameId, password } = req.body;
        if (!gameId || !password) {
            return res.status(400).json({ error: 'gameId and password are required' });
        }
        const user = await user_service_1.default.login(gameId, password);
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const token = (0, auth_1.generateToken)(user.id, user.gameId, user.isAdmin);
        res.json({
            token,
            user: {
                id: user.id,
                gameId: user.gameId,
                allianceName: user.allianceName,
                isAdmin: user.isAdmin,
            },
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 註冊
router.post('/register', async (req, res) => {
    try {
        const { gameId, password, allianceName, playerData } = req.body;
        if (!gameId || !password || !allianceName) {
            return res
                .status(400)
                .json({ error: 'gameId, password, and allianceName are required' });
        }
        const user = await user_service_1.default.register(gameId, password, allianceName, playerData);
        const token = (0, auth_1.generateToken)(user.id, user.gameId, user.isAdmin);
        res.status(201).json({
            token,
            user: {
                id: user.id,
                gameId: user.gameId,
                allianceName: user.allianceName,
                isAdmin: user.isAdmin,
            },
        });
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// 更新玩家遊戲資料（從遊戲 API 獲取的資料）
router.put('/player-data', auth_2.authMiddleware, async (req, res) => {
    try {
        const { nickname, kid, stoveLv, avatarImage } = req.body;
        const updated = await user_service_1.default.updatePlayerData(req.user.gameId, {
            nickname,
            kid,
            stoveLv,
            avatarImage,
        });
        res.json({ success: true, user: updated });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 取得當前使用者資料
router.get('/me', auth_2.authMiddleware, async (req, res) => {
    try {
        const user = await user_service_1.default.getUserById(req.user.id);
        res.json(user);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 更新使用者資料
router.put('/profile', auth_2.authMiddleware, async (req, res) => {
    try {
        const { allianceName, allianceId, coordinateX, coordinateY, powerPoints, T11Status } = req.body;
        const updated = await user_service_1.default.updateUserProfile(req.user.id, {
            allianceName,
            allianceId,
            coordinateX,
            coordinateY,
            powerPoints,
            T11Status,
        });
        res.json(updated);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 會員自行變更密碼
router.put('/change-password', auth_2.authMiddleware, async (req, res) => {
    try {
        const { oldPassword, newPassword } = req.body;
        if (!oldPassword || !newPassword) {
            return res.status(400).json({ error: 'Old password and new password are required' });
        }
        if (newPassword.length < 6) {
            return res.status(400).json({ error: 'New password must be at least 6 characters' });
        }
        await user_service_1.default.changePassword(req.user.gameId, oldPassword, newPassword);
        res.json({ message: 'Password changed successfully' });
    }
    catch (error) {
        if (error.message === 'Current password is incorrect') {
            return res.status(400).json({ error: error.message });
        }
        res.status(500).json({ error: error.message });
    }
});
// ======== 管理員 API ========
// 取得所有管理員
router.get('/admins', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const admins = await user_service_1.default.getAllAdmins();
        res.json(admins);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 設定管理員 (支持 POST /admins/:userId 和 PUT /users/:userId/admin)
router.post('/admins/:userId', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const { userId } = req.params;
        const { isAdmin } = req.body;
        const userIdStr = Array.isArray(userId) ? userId[0] : userId;
        const updated = await user_service_1.default.setAdminByGameId(userIdStr, isAdmin);
        res.json({
            message: isAdmin ? 'User promoted to admin' : 'Admin role removed',
            user: {
                id: updated.id,
                gameId: updated.gameId,
                allianceName: updated.allianceName,
                isAdmin: updated.isAdmin,
            },
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 設定管理員 (PUT 路由 - 前端使用)
router.put('/users/:userId/admin', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const { userId } = req.params;
        const { isAdmin, managedAlliances } = req.body;
        const userIdStr = Array.isArray(userId) ? userId[0] : userId;
        const updated = await user_service_1.default.setAdminByGameId(userIdStr, isAdmin, managedAlliances);
        res.json({
            message: isAdmin ? 'User promoted to admin' : 'Admin role removed',
            user: {
                id: updated.id,
                gameId: updated.gameId,
                allianceName: updated.allianceName,
                isAdmin: updated.isAdmin,
                managedAlliances: user_service_1.default.getManagedAlliances(updated),
            },
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 重設使用者密碼 (僅管理員)
router.put('/users/:gameId/reset-password', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const { gameId } = req.params;
        const { newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }
        const gameIdStr = Array.isArray(gameId) ? gameId[0] : gameId;
        const updated = await user_service_1.default.resetPassword(gameIdStr, newPassword);
        res.json({
            message: 'Password reset successfully',
            user: {
                id: updated.id,
                gameId: updated.gameId,
            },
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 取得所有使用者 (僅管理員)
router.get('/users', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const users = await user_service_1.default.getAllUsers();
        res.json({ users });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 刪除使用者 (僅管理員)
router.delete('/users/:userId', auth_2.authMiddleware, auth_2.adminMiddleware, async (req, res) => {
    try {
        const userIdStr = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
        await user_service_1.default.deleteUserByGameId(userIdStr);
        res.json({ message: 'User deleted successfully' });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// ======== 子帳號管理 API ========
// 新增子帳號
router.post('/sub-accounts', auth_2.authMiddleware, async (req, res) => {
    try {
        const { gameId, playerData } = req.body;
        if (!gameId) {
            return res.status(400).json({ error: 'gameId is required' });
        }
        const currentUser = await user_service_1.default.getUserById(req.user.id);
        if (!currentUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        // 確定主帳號 ID（如果當前用戶是子帳號，使用其主帳號 ID）
        const parentUserId = currentUser.parentUserId || currentUser.id;
        const result = await user_service_1.default.addSubAccount(parentUserId, gameId, currentUser.password, playerData);
        res.status(201).json(result);
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// 獲取關聯帳號列表
router.get('/sub-accounts', auth_2.authMiddleware, async (req, res) => {
    try {
        const currentUser = await user_service_1.default.getUserById(req.user.id);
        if (!currentUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        // 確定主帳號 ID
        const parentUserId = currentUser.parentUserId || currentUser.id;
        const accounts = await user_service_1.default.getLinkedAccounts(parentUserId);
        res.json({
            accounts,
            currentAccountId: req.user.id,
            parentUserId
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 切換到子帳號
router.post('/switch-account', auth_2.authMiddleware, async (req, res) => {
    try {
        const { targetGameId } = req.body;
        if (!targetGameId) {
            return res.status(400).json({ error: 'targetGameId is required' });
        }
        const currentUser = await user_service_1.default.getUserById(req.user.id);
        if (!currentUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        // 確定主帳號 ID
        const parentUserId = currentUser.parentUserId || currentUser.id;
        // 驗證目標帳號是否屬於同一個帳號群組
        const targetUser = await user_service_1.default.getUserByGameId(targetGameId);
        if (!targetUser) {
            return res.status(404).json({ error: 'Target account not found' });
        }
        const targetParentId = targetUser.parentUserId || targetUser.id;
        if (targetParentId !== parentUserId && targetUser.id !== parentUserId) {
            return res.status(403).json({ error: 'Target account is not linked' });
        }
        // 生成新 token
        const token = (0, auth_1.generateToken)(targetUser.id, targetUser.gameId, targetUser.isAdmin);
        res.json({
            token,
            user: {
                id: targetUser.id,
                gameId: targetUser.gameId,
                allianceName: targetUser.allianceName,
                isAdmin: targetUser.isAdmin,
            },
        });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// 移除子帳號綁定
router.delete('/sub-accounts/:gameId', auth_2.authMiddleware, async (req, res) => {
    try {
        const gameId = Array.isArray(req.params.gameId) ? req.params.gameId[0] : req.params.gameId;
        const currentUser = await user_service_1.default.getUserById(req.user.id);
        if (!currentUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        // 確定主帳號 ID
        const parentUserId = currentUser.parentUserId || currentUser.id;
        await user_service_1.default.removeSubAccount(parentUserId, gameId);
        res.json({ success: true, message: 'Sub-account unlinked' });
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=auth.js.map