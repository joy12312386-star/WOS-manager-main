import { Express } from 'express';
declare const app: Express;
export default app;
