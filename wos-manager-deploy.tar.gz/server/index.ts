import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import UserService from './services/user.service';

// Routes
import authRoutes from './routes/auth';
import submissionRoutes from './routes/submissions';
import statisticsRoutes from './routes/statistics';
import officerRoutes from './routes/officers';
import eventRoutes from './routes/events';

dotenv.config();

const app: Express = express();
const prisma = new PrismaClient();
const PORT = process.env.SERVER_PORT || 3001;

// Middleware
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/submissions', submissionRoutes);
app.use('/api/statistics', statisticsRoutes);
app.use('/api/officers', officerRoutes);
app.use('/api/events', eventRoutes);

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Start server
async function main() {
  try {
    // Initialize super admin
    await UserService.initializeSuperAdmin();

    app.listen(PORT, () => {
      console.log(`🚀 Server is running at http://localhost:${PORT}`);
      console.log(`📊 Database: ${process.env.DATABASE_URL}`);
      console.log(`🔗 Frontend: ${process.env.FRONTEND_URL}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down...');
  await prisma.$disconnect();
  process.exit(0);
});

main();

export default app;
