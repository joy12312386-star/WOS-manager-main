#!/usr/bin/env node
/**
 * 后端服务器启动脚本
 * 可通过 npm run dev:server 或直接运行此脚本
 */
export {};
